package com.simplemobiletools.commons.interfaces

interface LineColorPickerListener {
    fun colorChanged(index: Int, color: Int)
}
