package com.simplemobiletools.commons.interfaces

interface HashListener {
    fun receivedHash(hash: String, type: Int)
}
