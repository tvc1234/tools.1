package com.simplemobiletools.commons.models

data class License(val id: Int, val titleId: Int, val textId: Int, val urlId: Int)
