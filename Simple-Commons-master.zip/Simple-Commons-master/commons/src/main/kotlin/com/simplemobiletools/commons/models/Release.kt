package com.simplemobiletools.commons.models

data class Release(val id: Int, val textId: Int)
